import hashlib
import json
import logging
import os
import re
import smtplib
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from email.mime.text import MIMEText
from typing import Callable, Dict, List, Optional

import requests


LOG_FILE = "tcf_monitor.log"
CONFIG_FILE = "tcf_monitor_config.json"
ENV_FILE = "config.env"
TARGETS_FILE = "targets.json"

logger = logging.getLogger("tcf_monitor")
if not logger.handlers:
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)


def write_env(email: str, password: str, to_email: str, interval: int) -> None:
    with open(ENV_FILE, "w", encoding="utf-8") as f:
        f.write(f"EMAIL={email}\n")
        f.write(f"PASSWORD={password}\n")
        f.write(f"TO_EMAIL={to_email}\n")
        f.write(f"CHECK_INTERVAL={interval}\n")


def load_env() -> Dict[str, str]:
    data = {}
    if not os.path.exists(ENV_FILE):
        return data
    with open(ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or "=" not in line:
                continue
            k, v = line.split("=", 1)
            data[k] = v
    return data


def save_app_config(data: dict) -> None:
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_app_config() -> dict:
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def load_targets() -> List[dict]:
    with open(TARGETS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def normalize_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_focus_text(text: str, keywords: List[str]) -> str:
    raw = normalize_text(text)
    if not keywords:
        return raw[:5000]
    parts = []
    for kw in keywords:
        idx = raw.lower().find(kw.lower())
        if idx != -1:
            start = max(0, idx - 220)
            end = min(len(raw), idx + 420)
            parts.append(raw[start:end])
    if not parts:
        return raw[:5000]
    return " | ".join(parts)


def hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def send_email(subject: str, body: str, email: str, password: str, to_email: str) -> None:
    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = email
    msg["To"] = to_email

    server = smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=20)
    server.login(email, password)
    server.sendmail(email, [to_email], msg.as_string())
    server.quit()


@dataclass
class CheckResult:
    location: str
    available: bool
    changed: bool
    detail: str
    snapshot_hash: str


class MonitorEngine:
    def __init__(self, ui_callback: Optional[Callable[[str], None]] = None):
        self.ui_callback = ui_callback
        self.stop_event = threading.Event()
        self.thread: Optional[threading.Thread] = None
        self.state: Dict[str, Dict[str, str]] = {}

    def log(self, message: str) -> None:
        logger.info(message)
        if self.ui_callback:
            self.ui_callback(message)

    def fetch(self, url: str) -> str:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
        }
        r = requests.get(url, headers=headers, timeout=20)
        r.raise_for_status()
        return r.text

    def evaluate_target(self, target: dict) -> CheckResult:
        html = self.fetch(target["url"])
        focus = extract_focus_text(html, target.get("keywords", []))
        snap = hash_text(focus)

        name = target["name"]
        mode = target.get("mode", "change")
        previous = self.state.get(name, {})
        previous_hash = previous.get("snapshot_hash")

        changed = previous_hash is not None and previous_hash != snap
        available = False
        detail = target.get("note", "")

        if mode == "not_contains":
            blocked = target.get("keywords", [])
            available = all(word.lower() not in html.lower() for word in blocked)
            detail = "Keyword-based availability check"
        elif mode == "contains":
            required = target.get("keywords", [])
            available = all(word.lower() in html.lower() for word in required)
            detail = "Keyword-based availability check"
        else:
            available = changed
            detail = "Change detected in monitored section"

        self.state[name] = {
            "snapshot_hash": snap,
            "last_checked": datetime.now().isoformat()
        }

        return CheckResult(
            location=name,
            available=available,
            changed=changed,
            detail=detail,
            snapshot_hash=snap
        )

    def run_once(self, email: str, password: str, to_email: str, enabled_names: List[str]) -> None:
        targets = [t for t in load_targets() if t.get("enabled", True) and t["name"] in enabled_names]
        for t in targets:
            try:
                result = self.evaluate_target(t)
                self.log(f"Checked {result.location} | available={result.available} | changed={result.changed} | {result.detail}")
                previous = self.state.get(result.location, {})
                alerted_key = previous.get("last_alert_hash")

                if result.available and alerted_key != result.snapshot_hash:
                    subject = f"TCF Seat Alert - {result.location}"
                    body = (
                        f"检测到 {result.location} 可能有新变化或新考位。\n\n"
                        f"Location: {result.location}\n"
                        f"Rule: {result.detail}\n"
                        f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                        f"请尽快打开网站确认：\n{t['url']}\n"
                    )
                    send_email(subject, body, email, password, to_email)
                    self.state[result.location]["last_alert_hash"] = result.snapshot_hash
                    self.log(f"Alert email sent for {result.location}")
            except Exception as e:
                self.log(f"Error checking {t['name']}: {e}")

    def start(self, email: str, password: str, to_email: str, interval: int, enabled_names: List[str]) -> None:
        if self.thread and self.thread.is_alive():
            self.log("Monitor already running.")
            return

        self.stop_event.clear()

        def worker():
            self.log("Monitor started.")
            while not self.stop_event.is_set():
                self.run_once(email, password, to_email, enabled_names)
                for _ in range(interval):
                    if self.stop_event.is_set():
                        break
                    time.sleep(1)
            self.log("Monitor stopped.")

        self.thread = threading.Thread(target=worker, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
